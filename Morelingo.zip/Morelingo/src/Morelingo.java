import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class Morelingo implements KeyListener {
    private int mode;
    private int subMode;
    private String country;
    private ArrayList<String> pictures;
    private int pictureNumber;

    private JFrame frame;
    private JPanel panel;
    private JLabel welcomeBG;
    private JLabel gameBG;
    private JLabel nextPreviousButton;
    private JLabel howToUseBG;
    private JLabel creditsBG;
    private JLabel settingsBG;

    public Morelingo() {
        mode = 0;
        frame = new JFrame("Morelingo");
        frame.setPreferredSize(new Dimension(800, 670));
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dimension.width / 2 - 400, dimension.height / 2 - 335);
        ImageIcon icon = new ImageIcon("Morelingo Pictures/icon.png");
        frame.setIconImage(icon.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel();
        setMode();
        frame.add(panel);
        frame.addMouseListener(new MouseListener() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (mode == 0) {
                    if (e.getX() >= 73 && e.getX() <= 387 && e.getY() >= 385 && e.getY() <= 459 && e.getButton() == 1) {
                        mode = 1; //start
                        subMode = 1;
                        setMode();
                    } else if (e.getX() >= 413 && e.getX() <= 727 && e.getY() >= 345 && e.getY() <= 459 && e.getButton() == 1) {
                        mode = 2; //how to use
                        setMode();
                    } else if (e.getX() >= 73 && e.getX() <= 387 && e.getY() >= 450 && e.getY() <= 564 && e.getButton() == 1) {
                        mode = 3; //credits
                        setMode();
                    }
                    else if (e.getX() >= 413 && e.getX() <= 727 && e.getY() >= 450 && e.getY() <= 564 && e.getButton() == 1) {
                        mode = 4; //settings
                        setMode();
                    }
                } else if (mode == 1) {
                    if (subMode == 1) {
                        subMode = 2;
                        setSubMode();
                    } else if (subMode == 2) {
                        if (e.getX() >= 67 && e.getX() <= 728 && e.getY() >= 92 && e.getY() <= 250 && e.getButton() == 1) { //spain
                            country = "china";
                        } else if (e.getX() >= 67 && e.getX() <= 728 && e.getY() >= 269 && e.getY() <= 427 && e.getButton() == 1) { //chinese
                            country = "russia";
                        } else if (e.getX() >= 67 && e.getX() <= 728 && e.getY() >= 435 && e.getY() <= 594 && e.getButton() == 1) { //russian
                            country = "spain";
                        } else {
                            country = null;
                        }
                        if (country != null) {
                            subMode = 3;
                            mainGame(country);
                        }
                    } else if (subMode == 3) {
                        if (e.getX() <= 390 && e.getX() >= 260 && e.getY() >= 595 && e.getY() <= 640 && e.getButton() == 1) {
                            updatePicture("previous");
                        } else if (e.getX() <= 540 && e.getX() >= 410 && e.getY() >= 595 && e.getY() <= 640 && e.getButton() == 1) {
                            updatePicture("next");
                        }
                    }
                } else if (mode == 3) {
                    if (e.getButton() == 1) {
                        subMode = 2;
                        setSubMode();
                    }
                }
            }

            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        });
        frame.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (mode == 1) {
                    if (key == KeyEvent.VK_ESCAPE) {
                        if (subMode == 1) {
                            mode = 0;
                            setMode();
                        } else if (subMode == 2) {
                            subMode = 1;
                            setSubMode();
                        } else if (subMode == 3) {
                            subMode = 2;
                            setSubMode();
                        }
                    }
                } else {
                    if (key == KeyEvent.VK_ESCAPE) {
                        mode = 0;
                        setMode();
                    }
                }
            }

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);
    }

    public void setMode() {
        if (mode == 0) {
            ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/welcome.png");
            welcomeBG = new JLabel(imageIcon);
            welcomeBG.setPreferredSize(new Dimension(800, 670));
            panel.removeAll();
            panel.add(welcomeBG);
        } else if (mode == 1) {
            subMode = 1;
            setSubMode();
        } else if (mode == 2) {
            ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/howToUse.png");
            howToUseBG = new JLabel(imageIcon);
            howToUseBG.setPreferredSize(new Dimension(800, 670));
            panel.removeAll();
            panel.add(howToUseBG);
        } else if (mode == 3) {
            subMode = 1;
            setSubMode();
        }
        else if (mode == 4) {
            ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/pageNotFound.png");
            settingsBG = new JLabel(imageIcon);
            settingsBG.setPreferredSize(new Dimension(800, 670));
            panel.removeAll();
            panel.add(settingsBG);
        }
        panel.revalidate();
        panel.repaint();
    }
    
    public void setSubMode() {
        if (mode == 1) {
            if (subMode == 1) {
                ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/levels.png");
                gameBG = new JLabel(imageIcon);
                gameBG.setPreferredSize(new Dimension(800, 630));
                panel.removeAll();
                panel.add(gameBG);
            } else if (subMode == 2) {
                ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/languages.png");
                gameBG = new JLabel(imageIcon);
                gameBG.setPreferredSize(new Dimension(800, 670));
                panel.removeAll();
                panel.add(gameBG);
            }
        } else if (mode == 3) {
            if (subMode == 1) {
                ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/credits.png");
                creditsBG = new JLabel(imageIcon);
                creditsBG.setPreferredSize(new Dimension(800, 670));
                panel.removeAll();
                panel.add(creditsBG);
            } else if (subMode == 2) {
                ImageIcon imageIcon = new ImageIcon("Morelingo Pictures/pageNotFound.png");
                creditsBG = new JLabel(imageIcon);
                creditsBG.setPreferredSize(new Dimension(800, 670));
                panel.removeAll();
                panel.add(creditsBG);
            }
        }
        panel.revalidate();
        panel.repaint();
    }

    public void mainGame(String country) {
        pictureNumber = 0;
        pictures = new ArrayList<>();
        File tmpDir;
        boolean exists;
        int num = 1;
        do {
            tmpDir = new File("Morelingo Pictures/" + country + num + ".png");
            exists = tmpDir.exists();
            if (exists) {
                pictures.add("Morelingo Pictures/" + country + num + ".png");
            }
            num++;
        } while (exists);
        updatePicture("next");
    }

    public void updatePicture(String operation) {
        if (operation.equals("next")) {
            if (pictureNumber + 1 <= pictures.size()) {
                pictureNumber++;
            }
        } else if (operation.equals("previous")) {
            if (pictureNumber - 1 >= 1) {
                pictureNumber--;
            }
        }
        ImageIcon imageIcon = new ImageIcon(pictures.get(pictureNumber - 1));
        gameBG = new JLabel(imageIcon);
        gameBG.setPreferredSize(new Dimension(800, 550));
        panel.removeAll();
        panel.add(gameBG);
        ImageIcon imageIcon2 = new ImageIcon("Morelingo Pictures/next_previous.png");
        nextPreviousButton = new JLabel(imageIcon2);
        nextPreviousButton.setPreferredSize(new Dimension(800, 55));
        panel.add(nextPreviousButton);
        panel.revalidate();
        panel.repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (mode == 1) {
            if (key == KeyEvent.VK_ESCAPE) {
                if (subMode == 1) {
                    mode = 0;
                    setMode();
                } else if (subMode == 2) {
                    subMode = 1;
                    setSubMode();
                }
            } else if (key == KeyEvent.VK_RIGHT) {
                updatePicture("next");
            } else if (key == KeyEvent.VK_LEFT) {
                updatePicture("previous");
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public static void main(String[] args) {
        new Morelingo();
    }
}